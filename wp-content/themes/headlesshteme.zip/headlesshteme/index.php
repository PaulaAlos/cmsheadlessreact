<script type="text/javascript">
 // window.location = 'https://paudev.netlify.app/';
</script>